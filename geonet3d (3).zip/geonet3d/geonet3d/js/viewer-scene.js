/* ==========================================================================
   viewer-scene.js — Menu VISUALISASI (1/3): adegan Three.js
   Kamera, cahaya, grid, OrbitControls, dan ukuran layar 3D.
   ========================================================================== */
const view = document.getElementById('view');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0a0f1d);
const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 200);
camera.position.set(6, 6.5, 8);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
view.appendChild(renderer.domElement);
const controls = new THREE.OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; controls.dampingFactor = 0.08;
controls.target.set(0, 0.8, 0);

scene.add(new THREE.AmbientLight(0xffffff, 0.65));
const dl = new THREE.DirectionalLight(0xffffff, 0.8); dl.position.set(5, 10, 7); scene.add(dl);
const dl2 = new THREE.DirectionalLight(0x88aaff, 0.35); dl2.position.set(-6, 4, -5); scene.add(dl2);
const grid = new THREE.GridHelper(16, 32, 0x2a3a5c, 0x16213a); grid.position.y = -0.002; scene.add(grid);

function resize() {
  const w = view.clientWidth, h = view.clientHeight;
  if (!w || !h) return;
  renderer.setSize(w, h); camera.aspect = w / h; camera.updateProjectionMatrix();
}
new ResizeObserver(resize).observe(view); resize();
