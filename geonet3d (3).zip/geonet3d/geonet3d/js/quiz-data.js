/* ==========================================================================
   quiz-data.js — DATA KUIS (file yang paling sering diedit)
   - BANK   : daftar soal. Tambah/hapus soal cukup di sini (jumlah soal otomatis ikut).
              c = kategori (limas|prisma|kubus|balok), time = batas detik, q = pertanyaan,
              o = pilihan, a = indeks jawaban benar (mulai 0), e = pembahasan.
              Soal bergambar: tulis o: ['','','',''] dan n: [4 susunan petak [kolom,baris]].
   - REGION : nama, ikon, warna, dan cerita tiap daerah petualangan.
   ========================================================================== */
const NET_COL = ['#38bdf8', '#a78bfa', '#34d399', '#fbbf24', '#f472b6', '#fb923c'];
const CROSS = [[0, 1], [1, 1], [2, 1], [3, 1], [1, 0], [1, 2]];
const STAIR = [[0, 0], [1, 0], [1, 1], [2, 1], [2, 2], [3, 2]];
const TRI3 = [[0, 0], [1, 0], [2, 0], [2, 1], [3, 1], [4, 1]];
const BLOCK = [[0, 0], [1, 0], [0, 1], [1, 1], [2, 1], [3, 1]];

const REGION = {
  limas: { n: 'Hutan Limas', ic: 'fa-tree', g: 'from-emerald-700 to-emerald-950', story: 'Gerbang kayu berbentuk limas menghalangi jalanmu di tengah hutan.' },
  prisma: { n: 'Gua Prisma', ic: 'fa-gem', g: 'from-fuchsia-700 to-purple-950', story: 'Kristal prisma berkilau menutup pintu gua. Pecahkan teka-tekinya!' },
  kubus: { n: 'Kuil Kubus', ic: 'fa-landmark', g: 'from-sky-700 to-slate-900', story: 'Pintu kuil kuno terkunci oleh teka-teki kubus.' },
  balok: { n: 'Lembah Balok', ic: 'fa-cubes', g: 'from-amber-700 to-stone-900', story: 'Jembatan batu hanya terbuka bagi penjelajah yang cerdas.' }
};
/* 10 soal asesmen (urutan soal & pilihan diacak untuk setiap siswa) */
const BANK = [
  { c: 'limas', time: 30, q: 'Jaring-jaring limas segiempat terdiri atas ...', o: ['1 persegi dan 4 segitiga', '2 persegi dan 4 segitiga', '1 persegi dan 5 segitiga', '4 persegi dan 1 segitiga'], a: 0, e: 'Alas berbentuk persegi, dan keempat sisi tegaknya berupa segitiga.' },
  { c: 'limas', time: 50, q: 'Limas segiempat beraturan memiliki sisi alas 2 dan tinggi 2. Berapa tinggi segitiga pada sisi tegaknya?', o: ['√3', '√5', '2', '√8'], a: 1, e: 'Tinggi segitiga sisi tegak = √(tinggi limas² + (setengah sisi alas)²) = √(2² + 1²) = √5.' },
  { c: 'prisma', time: 30, q: 'Jaring-jaring prisma segitiga terdiri atas ...', o: ['3 segitiga dan 2 persegi panjang', '2 segitiga dan 3 persegi panjang', '2 segitiga dan 4 persegi panjang', '5 persegi panjang'], a: 1, e: 'Dua segitiga menjadi alas dan atap, tiga persegi panjang menjadi selimut.' },
  { c: 'prisma', time: 25, q: 'Berapa banyak rusuk yang dimiliki prisma segitiga?', o: ['6', '9', '12', '8'], a: 1, e: '3 rusuk alas + 3 rusuk atap + 3 rusuk tegak = 9 rusuk.' },
  { c: 'prisma', time: 30, q: 'Saat melipat selimut prisma segitiga sama sisi, berapa derajat tiap engsel dilipat dari posisi datar?', o: ['60°', '90°', '120°', '180°'], a: 2, e: 'Sudut dalam prisma segitiga sama sisi adalah 60°, sehingga lipatan dari posisi datar = 180° − 60° = 120°.' },
  { c: 'kubus', time: 35, q: 'Jaring kubus: empat persegi berderet A–B–C–D, persegi E di atas B, persegi F di bawah C. Persegi yang berhadapan dengan A adalah ...', o: ['B', 'C', 'D', 'E'], a: 1, e: 'Pada empat persegi berderet yang dilipat melingkar, A berhadapan dengan C, B dengan D, dan E dengan F.' },
  { c: 'kubus', time: 40, q: 'Manakah susunan berikut yang BUKAN jaring-jaring kubus?', o: ['', '', '', ''], n: [CROSS, STAIR, TRI3, BLOCK], a: 3, e: 'Susunan yang memuat blok 2 × 2 (empat persegi membentuk persegi besar) tidak dapat dilipat menjadi kubus karena ada persegi yang bertumpuk. Tiga susunan lainnya dapat dilipat menjadi kubus.' },
  { c: 'kubus', time: 40, q: 'Manakah susunan berikut yang merupakan jaring-jaring kubus?', o: ['', '', '', ''],
    n: [[[0, 1], [1, 1], [2, 1], [3, 1], [4, 1], [1, 0]], [[0, 1], [1, 1], [2, 1], [3, 1], [1, 0], [2, 2]], [[0, 1], [1, 1], [2, 1], [3, 1], [0, 0], [3, 0]], [[0, 1], [1, 1], [2, 1], [3, 1], [1, 0], [2, 0]]], a: 1,
    e: 'Pola 1-4-1 (empat persegi berderet, satu persegi di atas dan satu di bawah pada kolom berbeda) dapat dilipat menjadi kubus. Susunan lain memuat lima persegi berderet, dua persegi di sisi yang sama pada kedua ujung, atau blok 2 × 2 sehingga ada persegi yang bertumpuk.' },
  { c: 'balok', time: 30, q: 'Balok memiliki berapa pasang sisi yang berhadapan dan kongruen?', o: ['2 pasang', '3 pasang', '4 pasang', '6 pasang'], a: 1, e: 'Balok punya 6 sisi, terbagi menjadi 3 pasang sisi berhadapan yang sama bentuk dan ukuran.' },
  { c: 'balok', time: 45, q: 'Balok berukuran 3 × 2 × 1. Berapa luas permukaannya?', o: ['11', '18', '22', '36'], a: 2, e: 'L = 2(pl + pt + lt) = 2(6 + 3 + 2) = 22 satuan luas.' }
];
const TOTAL = BANK.length;
