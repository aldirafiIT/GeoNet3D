/* ==========================================================================
   audio.js — Efek suara dengan Web Audio API (tanpa file suara)
   tone() = bunyi dasar. snd() untuk kuis ada di quiz.js.
   ========================================================================== */
let actx = null;
function tone(freq, start, dur, type, vol) {
  const o = actx.createOscillator(), g = actx.createGain();
  o.type = type; o.frequency.value = freq;
  g.gain.setValueAtTime(vol, actx.currentTime + start);
  g.gain.exponentialRampToValueAtTime(0.001, actx.currentTime + start + dur);
  o.connect(g); g.connect(actx.destination);
  o.start(actx.currentTime + start); o.stop(actx.currentTime + start + dur);
}
function sfx(ok) {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
    if (ok) { tone(660, 0, 0.15, 'sine', 0.25); tone(880, 0.12, 0.25, 'sine', 0.25); }
    else { tone(220, 0, 0.2, 'sawtooth', 0.18); tone(150, 0.15, 0.3, 'sawtooth', 0.18); }
  } catch (e) { /* audio tidak tersedia */ }
}
