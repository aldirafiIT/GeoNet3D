/* ==========================================================================
   tabs.js — Perpindahan menu Materi / Visualisasi / Kuis
   Menu Materi & Visualisasi terkunci saat kuis berjalan (quizLock).
   ========================================================================== */
const TABS = { sim: ['tabSim', 'panelSim'], materi: ['tabMateri', 'panelMateri'], quiz: ['tabQuiz', 'panelQuiz'] };
function showTab(name) {
  if (quizLock && name !== 'quiz') return;
  Object.entries(TABS).forEach(([k, [b, p]]) => {
    document.getElementById(p).classList.toggle('hidden', k !== name);
    document.getElementById(b).className = 'px-3 py-1.5 rounded-lg text-sm font-semibold ' +
      (k === name ? 'bg-sky-500 text-slate-900' : 'bg-slate-800 text-slate-200');
  });
  document.getElementById('viewSec').classList.toggle('hidden', name !== 'sim');
  document.getElementById('side').classList.toggle('lg:col-span-3', name !== 'sim');
  if (name !== 'sim') setPlaying(false);
  if (name === 'quiz' && !phase) showIdentity();
}
Object.entries(TABS).forEach(([k, [b]]) => { document.getElementById(b).onclick = () => showTab(k); });
