/* ==========================================================================
   quiz.js — LOGIKA KUIS PETUALANGAN (mode asesmen)
   Urutan di file ini: peta -> identitas -> alur soal -> timer -> hasil.
   Dimuat SETELAH quiz-data.js. Bagian pengawasan (pindah tab, salin) ada di "pengawasan sederhana".
   ========================================================================== */
function netSvg(cells, cls) {
  const mx = Math.max(...cells.map(c => c[0])) + 1, my = Math.max(...cells.map(c => c[1])) + 1, u = 18;
  return `<svg viewBox="0 0 ${mx * u + 2} ${my * u + 2}" class="${cls || 'w-full h-16 sm:h-20'}">${cells.map(([x, y], i) =>
    `<rect x="${x * u + 1}" y="${y * u + 1}" width="${u}" height="${u}" fill="${NET_COL[i % 6]}" fill-opacity=".45" stroke="#e2e8f0" stroke-width="1.2"/>`).join('')}</svg>`;
}

const PTS = Array.from({ length: TOTAL + 1 }, (_, i) => [5 + i * (90 / TOTAL), 60 + 20 * Math.sin(i * 1.25)]);

let phase = '', quizLock = false, deck = [], ans = [], idx = 0, selected = -1, locked = false, startTs = 0, leaveCount = 0, away = false;
let timer = null, timeLeft = 0, timeMax = 30, lastTs = 0, qStart = 0;
let player = { nama: '', kelas: '' };

/* suara & efek (netral: tidak membocorkan benar/salah) */
function snd(kind) {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    if (actx.state === 'suspended') actx.resume();
    if (kind === 'tick') tone(900, 0, 0.05, 'square', 0.09);
    else if (kind === 'step') tone(330, 0, 0.07, 'triangle', 0.18);
    else if (kind === 'gate') { tone(392, 0, 0.12, 'triangle', 0.28); tone(523, 0.1, 0.12, 'triangle', 0.28); tone(659, 0.2, 0.25, 'triangle', 0.28); }
    else if (kind === 'win') [523, 659, 784, 1047].forEach((f, i) => tone(f, i * 0.12, 0.28, 'sine', 0.35));
    else if (kind === 'end') [440, 392, 349].forEach((f, i) => tone(f, i * 0.18, 0.3, 'sine', 0.25));
  } catch (e) { }
}
function confetti(n) {
  const f = $('fx');
  for (let i = 0; i < n; i++) {
    const d = document.createElement('div');
    d.style.cssText = `position:absolute;left:${Math.random() * 100}%;top:-14px;width:8px;height:12px;background:${NET_COL[i % 6]};animation:fall ${1.2 + Math.random() * 1.3}s ease-in forwards;`;
    f.appendChild(d); setTimeout(() => d.remove(), 2800);
  }
}
function setLock(v) {
  quizLock = v;
  ['tabMateri', 'tabSim'].forEach(id => {
    const b = $(id); b.disabled = v; b.title = v ? 'Selesaikan kuis terlebih dahulu' : '';
    b.classList.toggle('opacity-40', v); b.classList.toggle('cursor-not-allowed', v);
  });
  const musicToggle = $('musicToggle');
  musicToggle.disabled = v;
  musicToggle.title = v ? 'Musik terkunci selama kuis berlangsung' : '';
  $('panelQuiz').classList.toggle('noselect', v);

  // --- PENGATURAN MUSIK SAAT KUIS DIMULAI ---
  if (v === true) {
      // 1. Matikan total dan reset musik utama agar tidak bisa nyala lagi
      const mainBgm = document.getElementById('mainBgm');
      if (mainBgm) {
          mainBgm.pause();
          mainBgm.currentTime = 0;
          mainBgm.volume = 0; // Opsional: set volume jadi 0 sebagai pengaman ekstra
      }

      // 2. Nyalakan musik khusus kuis (Pou)
      const quizBgm = document.getElementById('quizBgm');
      if (quizBgm) {
          quizBgm.currentTime = 0;
          quizBgm.volume = 0.35;
          quizBgm.play().catch(e => console.log("Audio diblokir browser:", e));
      }
  } 
  // --- KETIKA KUIS SELESAI / DIBUKA KEMBALI (v === false) ---
  else {
      // Nyalakan kembali musik utama saat keluar dari kuis (opsional)
      const mainBgm = document.getElementById('mainBgm');
      if (mainBgm) {
          mainBgm.volume = 1;
          mainBgm.play().catch(e => console.log("Audio diblokir browser:", e));
      }
  }
}

/* pengawasan sederhana: catat saat siswa meninggalkan halaman; nonaktifkan salin/klik kanan */
function leave() { if (phase !== 'play' || away) return; away = true; leaveCount++; $('leaveNum').textContent = leaveCount; $('leaveBadge').classList.remove('hidden'); }
function comeBack() {
  if (phase === 'play' && away) {
    const w = $('warn'); w.textContent = `Peringatan: kamu meninggalkan halaman kuis (${leaveCount} kali). Aktivitas ini tercatat dalam hasil.`;
    w.classList.remove('hidden'); setTimeout(() => w.classList.add('hidden'), 4500);
  }
  away = false;
}
window.addEventListener('blur', leave); window.addEventListener('focus', comeBack);
document.addEventListener('visibilitychange', () => document.hidden ? leave() : comeBack());
['contextmenu', 'copy', 'cut', 'dragstart', 'selectstart'].forEach(ev =>
  $('panelQuiz').addEventListener(ev, e => { if (phase === 'play') e.preventDefault(); }));
window.addEventListener('beforeunload', e => { if (phase === 'play') { e.preventDefault(); e.returnValue = ''; } });

/* timer (tidak bisa ditambah atau dijeda) */
function updTimer() {
  const bar = $('timerBar'); if (!bar) return;
  bar.style.width = (Math.max(0, timeLeft / timeMax) * 100) + '%';
  bar.className = 'h-full ' + (timeLeft <= 5 ? 'bg-rose-500' : timeLeft <= 10 ? 'bg-amber-400' : 'bg-sky-400');
  $('timeTxt').textContent = Math.ceil(timeLeft);
}
function stopTimer() { clearInterval(timer); timer = null; }
function startTimer(sec) {
  stopTimer(); timeMax = timeLeft = sec; lastTs = performance.now(); updTimer();
  timer = setInterval(() => {
    const now = performance.now(), dt = (now - lastTs) / 1000; lastTs = now;
    const prev = Math.ceil(timeLeft); timeLeft -= dt;
    if (timeLeft <= 0) { timeLeft = 0; updTimer(); stopTimer(); lockIn(true); return; }
    if (timeLeft <= 5 && Math.ceil(timeLeft) !== prev) snd('tick');
    updTimer();
  }, 100);
}

/* ---------- layar identitas ---------- */
function showIdentity() {
  stopTimer(); phase = 'ident'; setLock(false);
  $('quizStatus').classList.add('hidden');
  $('quizBody').innerHTML = `<div class="pop max-w-sm mx-auto">
    <div class="text-center mb-4">
      <div class="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-emerald-500 to-amber-400 flex items-center justify-center text-3xl text-white shadow-lg"><i class="fa-solid fa-person-hiking"></i></div>
      <div class="text-xl font-extrabold mt-2">Petualangan Jelajah 3D</div>
      <div class="text-xs text-slate-400">Lewati 10 pos untuk menemukan Harta Karun Geometri!</div>
      <div class="text-xs text-slate-300 mt-2 text-left bg-slate-800 rounded-xl p-3 space-y-1">
        <div><i class="fa-solid fa-map-location-dot text-sky-300 w-4 mr-1"></i>Setiap pos berisi 1 soal. Urutan soal dan pilihan diacak.</div>
        <div><i class="fa-solid fa-clock text-amber-300 w-4 mr-1"></i>Ada batas waktu tiap soal. Waktu tidak bisa ditambah.</div>
        <div><i class="fa-solid fa-key text-emerald-300 w-4 mr-1"></i>Setelah gerbang dibuka, jawaban tidak dapat diubah.</div>
        <div><i class="fa-solid fa-trophy text-rose-300 w-4 mr-1"></i>Hasil muncul otomatis setelah pos terakhir.</div>
        <div><i class="fa-solid fa-triangle-exclamation text-rose-300 w-4 mr-1"></i>Meninggalkan halaman kuis akan dicatat.</div>
      </div>
    </div>
    <div class="text-center text-sm font-semibold mb-2"><i class="fa-solid fa-id-card mr-1 text-sky-300"></i>Isi identitas sebelum bermain</div>
    <label class="text-sm text-slate-300" for="nm">Nama</label>
    <input id="nm" maxlength="40" value="${esc(player.nama)}" placeholder="Nama lengkap" class="w-full mb-2 px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:outline-none focus:border-sky-400">
    <label class="text-sm text-slate-300" for="kl">Kelas</label>
    <input id="kl" maxlength="12" value="${esc(player.kelas)}" placeholder="Contoh: VIII A" class="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 focus:outline-none focus:border-sky-400">
    <div id="err" class="text-rose-400 text-sm mt-2 min-h-5"></div>
    <button id="go" class="mt-1 w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-amber-400 hover:opacity-90 text-slate-900 font-extrabold"><i class="fa-solid fa-play mr-1"></i>Mulai Petualangan</button></div>`;
  const go = () => {
    const nama = $('nm').value.trim(), kelas = $('kl').value.trim();
    if (!nama || !kelas) { $('err').textContent = 'Nama dan kelas wajib diisi.'; return; }
    player = { nama, kelas }; startQuiz();
  };
  $('go').onclick = go;
  ['nm', 'kl'].forEach(id => $(id).addEventListener('keydown', e => { if (e.key === 'Enter') go(); }));
}

/* ---------- peta petualangan ---------- */
function buildMap() {
  return `<div id="map" class="relative w-full h-36 sm:h-44 rounded-2xl overflow-hidden bg-gradient-to-b from-sky-950 to-emerald-950 border border-slate-700 mb-3">
    <svg viewBox="0 0 100 100" preserveAspectRatio="none" class="absolute inset-0 w-full h-full"><polyline points="${PTS.map(p => p.join(',')).join(' ')}" fill="none" stroke="#fbbf24" stroke-opacity=".55" stroke-width="2" stroke-dasharray="5 4" vector-effect="non-scaling-stroke"/></svg>
    ${PTS.map((p, i) => `<div id="n${i}" class="absolute w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-[10px] sm:text-xs" style="left:${p[0]}%;top:${p[1]}%;transform:translate(-50%,-50%);"></div>`).join('')}
    <div id="hero" class="absolute z-10 w-7 h-7 sm:w-9 sm:h-9 rounded-full bg-rose-500 border-2 border-white text-white flex items-center justify-center text-xs sm:text-sm shadow-lg" style="left:${PTS[0][0]}%;top:${PTS[0][1]}%;transform:translate(-50%,-135%);transition:left 1.1s ease-in-out, top 1.1s ease-in-out;"><i class="fa-solid fa-person-hiking"></i></div>
  </div><div id="stage"></div>`;
}
function updMap() {
  PTS.forEach((_, i) => {
    const n = $('n' + i); if (!n) return;
    let cls, inner;
    if (i === TOTAL) { cls = 'bg-amber-400/20 text-amber-300 border border-amber-400/60'; inner = '<i class="fa-solid fa-box-open"></i>'; if (idx >= TOTAL) cls += ' animate-bounce'; }
    else if (i < idx) { cls = 'bg-amber-500 text-slate-900'; inner = '<i class="fa-solid fa-star"></i>'; }
    else if (i === idx) { cls = 'bg-sky-500 text-slate-900 animate-pulse ring-2 ring-sky-300'; inner = `<span class="num font-bold">${i + 1}</span>`; }
    else { cls = 'bg-slate-700 text-slate-400'; inner = `<span class="num">${i + 1}</span>`; }
    n.className = 'absolute w-6 h-6 sm:w-8 sm:h-8 rounded-full flex items-center justify-center text-[10px] sm:text-xs ' + cls; n.innerHTML = inner;
  });
}
async function moveHero(i) {
  const h = $('hero'); h.style.left = PTS[i][0] + '%'; h.style.top = PTS[i][1] + '%';
  for (let k = 0; k < 4; k++) { snd('step'); await sleep(260); }
}

/* ---------- alur ---------- */
async function startQuiz() {
  if (phase === 'play') return;
  phase = 'play'; setLock(true); stopTimer();
  deck = shuffle(BANK).map(q => ({ ...q, order: shuffle(q.o.map((_, i) => i)) }));
  ans = []; idx = 0; leaveCount = 0; away = false;
  $('leaveBadge').classList.add('hidden'); $('leaveNum').textContent = '0';
  $('quizStatus').classList.remove('hidden');
  $('whoName').textContent = player.nama; $('whoClass').textContent = 'Kelas ' + player.kelas;

  for (let count = 3; count > 0; count--) {
    $('quizBody').innerHTML = `<div class="min-h-64 flex flex-col items-center justify-center text-center pop">
      <div class="text-sm uppercase tracking-[0.3em] text-sky-300 font-bold">Bersiap!</div>
      <div class="text-8xl font-extrabold text-amber-300 my-3">${count}</div>
      <div class="text-slate-300">Kuis dimulai dalam hitungan...</div>
    </div>`;
    snd('tick');
    await sleep(1000);
  }

  startTs = Date.now();
  $('quizBody').innerHTML = buildMap(); updMap(); snd('gate'); renderStation();
}
function renderStation() {
  const Q = deck[idx], R = REGION[Q.c], isNet = !!Q.n;
  selected = -1; locked = false; $('qNow').textContent = idx + 1; updMap();
  $('stage').innerHTML = `<div class="pop">
    <div class="rounded-xl bg-gradient-to-br ${R.g} p-3 mb-3 flex items-center gap-3">
      <div class="text-2xl w-12 h-12 shrink-0 rounded-full bg-black/30 flex items-center justify-center"><i class="fa-solid ${R.ic}"></i></div>
      <div><div class="text-xs text-white/70">Pos ${idx + 1} dari ${TOTAL}</div><div class="font-extrabold">${R.n}</div><div class="text-xs text-white/80">${R.story}</div></div>
    </div>
    <div class="mb-3">
      <div class="h-3 rounded-full bg-slate-800 overflow-hidden"><div id="timerBar" class="h-full bg-sky-400" style="width:100%"></div></div>
      <div class="flex justify-end text-xs mt-1 text-slate-400"><span><i class="fa-solid fa-clock mr-1"></i><span id="timeTxt" class="num">${Q.time}</span> dtk</span></div>
    </div>
    <div class="text-base sm:text-lg font-semibold mb-3 leading-snug">${Q.q}</div>
    <div class="grid ${isNet ? 'grid-cols-2' : 'sm:grid-cols-2'} gap-2">${Q.order.map((oi, k) =>
      `<button class="opt text-left px-3 py-2.5 rounded-xl border-2 border-slate-700 bg-slate-800 hover:border-sky-400 transition" data-k="${k}">
        <span class="inline-block w-6 h-6 mr-2 text-center rounded-md bg-slate-700 text-xs leading-6 font-bold">${String.fromCharCode(65 + k)}</span>${isNet ? netSvg(Q.n[oi]) : Q.o[oi]}</button>`).join('')}</div>
    <button id="submit" disabled class="mt-4 w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-900 font-extrabold disabled:opacity-40 disabled:cursor-not-allowed"><i class="fa-solid fa-key mr-1"></i>Buka Gerbang</button></div>`;
  $('stage').querySelectorAll('.opt').forEach(b => b.onclick = () => {
    if (locked) return; selected = +b.dataset.k;
    $('stage').querySelectorAll('.opt').forEach(x => x.className = 'opt text-left px-3 py-2.5 rounded-xl border-2 border-slate-700 bg-slate-800 hover:border-sky-400 transition');
    b.className = 'opt text-left px-3 py-2.5 rounded-xl border-2 border-sky-400 bg-sky-600/25 transition';
    $('submit').disabled = false;
  });
  $('submit').onclick = () => lockIn(false);
  qStart = Date.now(); startTimer(Q.time);
}
async function lockIn(timeout) {
  if (locked) return; locked = true; stopTimer();
  const Q = deck[idx], sel = selected, ok = sel >= 0 && Q.order[sel] === Q.a;
  ans[idx] = { sel, ok, timeout, sec: Math.round((Date.now() - qStart) / 1000) };
  snd('gate');
  $('stage').innerHTML = `<div class="text-center py-8 pop"><div class="text-5xl text-amber-300 mb-2"><i class="fa-solid fa-door-open"></i></div>
    <div class="font-bold">${timeout ? 'Waktu habis. Jawabanmu tercatat.' : 'Jawabanmu tercatat.'}</div>
    <div class="text-sm text-slate-400">Gerbang terbuka, perjalanan berlanjut...</div></div>`;
  await sleep(700);
  idx++; updMap(); await moveHero(idx);
  if (idx >= TOTAL) { $('stage').innerHTML = `<div class="text-center py-8 pop"><div class="text-5xl text-amber-300 mb-2"><i class="fa-solid fa-box-open"></i></div><div class="font-bold">Kamu tiba di Harta Karun Geometri!</div><div class="text-sm text-slate-400">Menghitung hasil petualanganmu...</div></div>`; await sleep(1500); finish(); return; }
  renderStation();
}
/* ---------- hasil (otomatis setelah soal terakhir) ---------- */
function finish() {
  stopTimer(); phase = 'result'; setLock(false);
  
  // --- MUSIK BERHENTI OTOMATIS SAAT KUIS SELESAI ---
  const quizBgm = document.getElementById('quizBgm');
  if (quizBgm) {
      quizBgm.pause();
  }
  // ------------------------------------------------

  const benar = ans.filter(a => a && a.ok).length, nilai = Math.round(benar / TOTAL * 100);
  const sec = Math.round((Date.now() - startTs) / 1000), mm = Math.floor(sec / 60), ss = String(sec % 60).padStart(2, '0');
  const stars = nilai >= 80 ? 3 : nilai >= 60 ? 2 : nilai >= 40 ? 1 : 0;
  const gelar = nilai >= 90 ? 'Penjelajah Legendaris' : nilai >= 70 ? 'Petualang Hebat' : nilai >= 50 ? 'Petualang Muda' : 'Calon Petualang';
  const review = deck.map((Q, i) => {
    const a = ans[i] || { sel: -1, ok: false }, R = REGION[Q.c], isNet = !!Q.n;
    const letter = k => String.fromCharCode(65 + k), kunciK = Q.order.indexOf(Q.a);
    const yours = a.sel < 0 ? '<i>tidak menjawab</i>' : isNet ? 'Pilihan ' + letter(a.sel) : esc(Q.o[Q.order[a.sel]]);
    const key = isNet ? 'Pilihan ' + letter(kunciK) : esc(Q.o[Q.a]);
    return `<div class="rounded-xl bg-slate-800 border ${a.ok ? 'border-emerald-600' : 'border-rose-600'} p-3 text-sm text-left">
      <div class="flex items-center gap-2 mb-1"><i class="fa-solid ${a.ok ? 'fa-circle-check text-emerald-400' : 'fa-circle-xmark text-rose-400'}"></i><b>Soal ${i + 1}</b><span class="text-xs text-slate-400">${R.n}</span></div>
      <div class="mb-1">${Q.q}</div>
      ${isNet ? `<div class="w-24 mb-1">${netSvg(Q.n[Q.a], 'w-full h-14')}</div>` : ''}
      <div class="text-xs text-slate-300">Jawabanmu: <b>${yours}</b> • Kunci: <b class="text-emerald-300">${key}</b></div>
      <div class="text-xs text-slate-400 mt-1">${Q.e}</div></div>`;
      
  }).join('');
  $('quizBody').innerHTML = `<div class="text-center pop">
    <div class="text-4xl mb-1 text-amber-300"><i class="fa-solid fa-trophy"></i></div>
    <div class="text-xl font-extrabold">PETUALANGAN SELESAI!</div>
    <div class="text-2xl my-2 text-amber-300">${[0, 1, 2].map(i => `<i class="fa-${i < stars ? 'solid' : 'regular'} fa-star"></i>`).join(' ')}</div>
    <div class="inline-block px-3 py-1 rounded-full bg-emerald-600/30 border border-emerald-500 text-emerald-200 text-sm font-bold mb-2"><i class="fa-solid fa-medal mr-1"></i>${gelar}</div>
    <div class="mt-2 rounded-xl bg-slate-800 border border-slate-700 p-3 text-sm text-left space-y-1 max-w-sm mx-auto">
      <div class="flex justify-between"><span class="text-slate-400">Nama</span><b>${esc(player.nama)}</b></div>
      <div class="flex justify-between"><span class="text-slate-400">Kelas</span><b>${esc(player.kelas)}</b></div>
      <div class="flex justify-between"><span class="text-slate-400">Jawaban benar</span><b>${benar} / ${TOTAL}</b></div>
      <div class="flex justify-between"><span class="text-slate-400">Waktu total</span><b>${mm}:${ss}</b></div>
      <div class="flex justify-between"><span class="text-slate-400">Keluar halaman</span><b class="${leaveCount ? 'text-rose-300' : 'text-emerald-300'}">${leaveCount} kali</b></div>
    </div>
    <div class="mt-3 text-slate-400 text-sm">Nilai Akhir</div>
    <div class="text-6xl font-extrabold text-sky-300">${nilai}</div>
    <div class="text-sm text-slate-300 mb-3">${nilai >= 80 ? 'Sangat Baik' : nilai >= 60 ? 'Baik' : nilai >= 40 ? 'Cukup' : 'Perlu Belajar Lagi'}</div>
    <details class="max-w-xl mx-auto text-left mb-4"><summary class="cursor-pointer text-sky-300 font-semibold text-center mb-2"><i class="fa-solid fa-list-check mr-1"></i>Lihat pembahasan</summary><div class="space-y-2 mt-2">${review}</div></details>
    <button id="again" class="px-5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-amber-400 text-slate-900 font-bold"><i class="fa-solid fa-rotate-right mr-1"></i>Kembali ke Awal</button></div>`;
  $('again').onclick = showIdentity;
  if (stars > 0) { snd('win'); confetti(80); } else snd('end');
}
