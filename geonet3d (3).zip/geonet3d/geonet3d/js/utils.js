/* ==========================================================================
   utils.js — Fungsi bantu umum + font angka "equation"
   Dimuat PALING AWAL karena dipakai file lain.
   ========================================================================== */

/* Pintasan DOM, pengaman teks, jeda, dan acak urutan */
const $ = id => document.getElementById(id);
const esc = x => String(x).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const shuffle = arr => { const a = arr.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

/* Membungkus angka & simbol matematika dengan font "equation" (kelas .num) */
const NUM_RE = /(\d+(?:[.,]\d+)?[°%]?|[√×÷²³⅓⅔°=+−])/g;
function numify(root) {
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const list = [];
  while (w.nextNode()) {
    const n = w.currentNode, p = n.parentElement;
    if (p && !p.closest('.num, .eq, script, style, textarea, input') && /[\d√×÷²³⅓⅔°=+−]/.test(n.nodeValue)) list.push(n);
  }
  list.forEach(n => {
    const parts = n.nodeValue.split(NUM_RE), frag = document.createDocumentFragment();
    parts.forEach((t, i) => {
      if (!t) return;
      if (i % 2) { const sp = document.createElement('span'); sp.className = 'num'; sp.textContent = t; frag.appendChild(sp); }
      else frag.appendChild(document.createTextNode(t));
    });
    n.parentNode.replaceChild(frag, n);
  });
}
