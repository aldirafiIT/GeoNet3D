/* ==========================================================================
   materi.js — Isi tab MATERI (teks + gambar contoh bangun ruang & jaring-jaring)
   Mau ubah teks materi?  -> edit array MATERI di bawah.
   Mau ubah gambar?       -> edit fungsi gambar di bagian "GAMBAR SVG".
   Semua gambar digambar lewat kode (SVG), jadi tidak perlu file gambar.
   ========================================================================== */

/* ---------- GAMBAR SVG (kanvas 160 x 130) ---------- */
const SVG_STROKE = 'stroke="#e2e8f0" stroke-width="1.5" stroke-linejoin="round"';
const svgPts = l => l.map(([x, y]) => `${x},${y}`).join(' ');
// svgP = bidang (poligon), svgD = garis putus-putus (rusuk tersembunyi), svgR = persegi panjang
const svgP = (l, c = '#38bdf8', o = .35) => `<polygon points="${svgPts(l)}" fill="${c}" fill-opacity="${o}" ${SVG_STROKE}/>`;
const svgD = (a, b) => `<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#e2e8f0" stroke-width="1.2" stroke-dasharray="4 3" stroke-opacity=".7"/>`;
const svgR = (x, y, w, h, c = '#38bdf8', o = .35) => svgP([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], c, o);
const svg160 = body => `<svg viewBox="0 0 160 130" class="w-full h-auto" role="img">${body}</svg>`;

function boxSolid(A, B, C, Dd, dx, dy) {
  const A2 = [A[0] + dx, A[1] + dy], B2 = [B[0] + dx, B[1] + dy], C2 = [C[0] + dx, C[1] + dy], D2 = [Dd[0] + dx, Dd[1] + dy];
  return svgD(A2, D2) + svgD(D2, C2) + svgD(Dd, D2) + svgP([A, B, C, Dd], '#38bdf8', .35) + svgP([A, B, B2, A2], '#38bdf8', .65) + svgP([B, C, C2, B2], '#38bdf8', .18);
}
const GAMBAR = {
  kubus: svg160(boxSolid([30, 50], [90, 50], [90, 110], [30, 110], 25, -20)),
  balok: svg160(boxSolid([20, 55], [100, 55], [100, 105], [20, 105], 30, -25)),
  prisma: (() => {
    const P1 = [25, 105], P2 = [85, 105], P3 = [55, 55], Q1 = [70, 80], Q2 = [130, 80], Q3 = [100, 30];
    return svg160(svgD(P1, Q1) + svgD(Q1, Q2) + svgP([P1, P3, Q3, Q1], '#f472b6', .5) + svgP([P3, Q3, Q2, P2], '#f472b6', .2) + svgP([P1, P2, P3], '#f472b6', .38));
  })(),
  limas: (() => {
    const A = [30, 95], B = [100, 95], C = [130, 75], Dp = [60, 75], T = [80, 22];
    return svg160(svgD(A, Dp) + svgD(Dp, C) + svgD(T, Dp) + svgP([T, A, B], '#fbbf24', .5) + svgP([T, B, C], '#fbbf24', .2) + svgP([A, B, C, Dp], '#fbbf24', .3));
  })()
};
const JARING = {
  kubus: svg160([30, 54, 78, 102].map(x => svgR(x, 53, 24, 24)).join('') + svgR(54, 29, 24, 24, '#a78bfa', .45) + svgR(54, 77, 24, 24, '#a78bfa', .45)),
  balok: svg160(svgR(20, 53, 24, 20, '#34d399', .3) + svgR(44, 53, 36, 20, '#34d399', .5) + svgR(80, 53, 24, 20, '#34d399', .3) + svgR(104, 53, 36, 20, '#34d399', .5)
    + svgR(44, 29, 36, 24, '#34d399', .2) + svgR(44, 73, 36, 24, '#34d399', .2)),
  prisma: svg160(svgR(40, 45, 30, 40, '#f472b6', .4) + svgR(70, 45, 30, 40, '#f472b6', .4) + svgR(100, 45, 30, 40, '#f472b6', .4)
    + svgP([[70, 45], [100, 45], [85, 19]], '#f472b6', .22) + svgP([[70, 85], [100, 85], [85, 111]], '#f472b6', .22)),
  limas: svg160(svgR(62, 47, 36, 36, '#fbbf24', .4) + svgP([[62, 47], [98, 47], [80, 15]], '#fbbf24', .2) + svgP([[62, 83], [98, 83], [80, 115]], '#fbbf24', .2)
    + svgP([[62, 47], [62, 83], [30, 65]], '#fbbf24', .2) + svgP([[98, 47], [98, 83], [130, 65]], '#fbbf24', .2))
};

/* ---------- TEKS MATERI (edit di sini) ---------- */
const MATERI_INTRO = 'Jaring-jaring adalah rangkaian bidang datar hasil membuka permukaan bangun ruang hingga rebah pada satu bidang. Bila dilipat kembali pada rusuk-rusuknya, jaring-jaring membentuk bangun ruang semula. Garis putus-putus pada gambar menunjukkan rusuk yang tersembunyi di balik bangun ruang.';
const MATERI = [
  { judul: 'Kubus', ikon: 'fa-cube', kunci: 'kubus',
    unsur: '6 sisi persegi kongruen, 12 rusuk, 8 titik sudut.',
    jaring: '6 persegi (misalnya pola salib); ada 11 bentuk jaring-jaring berbeda.',
    rumus: 'V = s³; L = 6 × s²' },
  { judul: 'Balok', ikon: 'fa-box', kunci: 'balok',
    unsur: '6 sisi persegi panjang (3 pasang kongruen), 12 rusuk, 8 titik sudut.',
    jaring: '3 pasang persegi panjang yang saling berhadapan.',
    rumus: 'V = p × l × t; L = 2(pl + pt + lt)' },
  { judul: 'Prisma Segitiga', ikon: 'fa-caret-up', kunci: 'prisma',
    unsur: '5 sisi (2 segitiga + 3 persegi panjang), 9 rusuk, 6 titik sudut.',
    jaring: '2 segitiga alas/atap dan 3 persegi panjang selimut.',
    rumus: 'V = L<sub>alas</sub> × t; L = 2 × L<sub>alas</sub> + K<sub>alas</sub> × t' },
  { judul: 'Limas Segiempat', ikon: 'fa-play fa-rotate-270', kunci: 'limas',
    unsur: '5 sisi (1 alas + 4 segitiga), 8 rusuk, 5 titik sudut.',
    jaring: '1 persegi alas dan 4 segitiga sisi tegak.',
    rumus: 'V = ⅓ × L<sub>alas</sub> × t; L = L<sub>alas</sub> + 4 × L<sub>segitiga</sub>' }
];

/* ---------- RENDER (jangan diubah kecuali ingin ganti tata letak kartu) ---------- */
function renderMateri() {
  const kartu = MATERI.map(m => `
      <div class="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-sm text-slate-300">
        <div class="font-bold text-sky-300 mb-2"><i class="fa-solid ${m.ikon} mr-1"></i>${m.judul}</div>
        <div class="grid grid-cols-2 gap-2 mb-3">
          <figure class="bg-slate-950 rounded-xl p-2 text-center">${GAMBAR[m.kunci]}<figcaption class="text-xs text-slate-400">Bangun ruang</figcaption></figure>
          <figure class="bg-slate-950 rounded-xl p-2 text-center">${JARING[m.kunci]}<figcaption class="text-xs text-slate-400">Jaring-jaring</figcaption></figure>
        </div>
        <div class="space-y-1">
          <div><b>Unsur:</b> ${m.unsur}</div>
          <div><b>Jaring-jaring:</b> ${m.jaring}</div>
          <div><b>Rumus:</b> <span class="eq">${m.rumus}</span></div>
        </div>
      </div>`).join('');
  document.getElementById('panelMateri').innerHTML = `
      <div class="md:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-4 text-sm text-slate-300">
        <div class="font-bold text-sky-300 mb-1"><i class="fa-solid fa-lightbulb mr-1"></i>Apa itu jaring-jaring?</div>
        ${MATERI_INTRO}
      </div>${kartu}`;
}
