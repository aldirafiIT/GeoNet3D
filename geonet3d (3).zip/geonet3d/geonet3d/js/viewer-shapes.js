/* ==========================================================================
   viewer-shapes.js — Menu VISUALISASI (2/3): bidang, engsel, dan bentuk bangun ruang
   face() = satu bidang + engsel. SHAPES = limas, prisma, kubus, balok.
   Ubah tinggi limas lewat H_PYR, ukuran balok lewat box(r, p, l, t).
   ========================================================================== */
let root = null, folds = [];
const COLORS = [0x38bdf8, 0xf472b6, 0xfbbf24, 0x34d399, 0xa78bfa, 0xfb923c];
let colorIdx = 0;

// Membuat bidang datar (di Y=0, koordinat lokal [x,z]) yang dipasang pada engsel.
// Engsel: posisi (x,y,z) & ry => sumbu engsel = sumbu X lokal, arah "keluar" = +Z lokal.
function face(parent, pts, h, max) {
  const hinge = new THREE.Group();
  hinge.position.set(h.x || 0, h.y || 0, h.z || 0);
  hinge.rotation.y = h.ry || 0;
  parent.add(hinge);
  const fold = new THREE.Group();
  hinge.add(fold);

  const pos = [];
  for (let i = 1; i < pts.length - 1; i++) {
    [pts[0], pts[i], pts[i + 1]].forEach(p => pos.push(p[0], 0, p[1]));
  }
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  geo.computeVertexNormals();
  const color = COLORS[colorIdx++ % COLORS.length];
  const mesh = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
    color, side: THREE.DoubleSide, transparent: true, opacity: 0.92, roughness: 0.55, metalness: 0.05
  }));
  const edges = new THREE.LineSegments(new THREE.EdgesGeometry(geo), new THREE.LineBasicMaterial({ color: 0xffffff }));
  mesh.add(edges);
  fold.add(mesh);
  if (max) folds.push({ g: fold, max });
  return fold;
}
const rect = (w, d) => [[-w / 2, 0], [w / 2, 0], [w / 2, d], [-w / 2, d]];
const deg = r => r * 180 / Math.PI;
const PI = Math.PI;

/* ================== BANGUN RUANG ================== */
const H_PYR = 1.8;
const hs = Math.sqrt(1 + H_PYR * H_PYR);
const theta = Math.acos(1 / hs); // sudut dihedral interior

const SHAPES = {
  limas: {
    name: 'Limas Segiempat', icon: 'fa-play fa-rotate-270', f: 5, e: 8, v: 5,
    build(r) {
      face(r, [[-1, -1], [1, -1], [1, 1], [-1, 1]], {});
      const max = PI - theta;
      [[0, 0, 1], [PI / 2, 1, 0], [PI, 0, -1], [-PI / 2, -1, 0]].forEach(([ry, x, z]) =>
        face(r, [[-1, 0], [1, 0], [0, hs]], { x, z, ry }, max));
    }
  },
  prisma: {
    name: 'Prisma Segitiga', icon: 'fa-caret-up', f: 5, e: 9, v: 6,
    build(r) {
      const L = 3, s3 = Math.sqrt(3);
      face(r, [[-1, -L / 2], [1, -L / 2], [1, L / 2], [-1, L / 2]], {});
      face(r, rect(L, 2), { x: 1, ry: PI / 2 }, 2 * PI / 3);
      face(r, rect(L, 2), { x: -1, ry: -PI / 2 }, 2 * PI / 3);
      face(r, [[-1, 0], [1, 0], [0, s3]], { z: L / 2, ry: 0 }, PI / 2);
      face(r, [[-1, 0], [1, 0], [0, s3]], { z: -L / 2, ry: PI }, PI / 2);
    }
  },
  kubus: {
    name: 'Kubus', icon: 'fa-cube', f: 6, e: 12, v: 8,
    build(r) { box(r, 2, 2, 2); }
  },
  balok: {
    name: 'Balok', icon: 'fa-box', f: 6, e: 12, v: 8,
    build(r) { box(r, 3, 2, 1.5); }
  }
};

function box(r, l, w, h) {
  face(r, [[-l / 2, -w / 2], [l / 2, -w / 2], [l / 2, w / 2], [-l / 2, w / 2]], {});
  const q = PI / 2;
  const top = face(r, rect(l, h), { z: w / 2, ry: 0 }, q);
  face(top, rect(l, w), { z: h, ry: 0 }, q);               // tutup, bertingkat
  face(r, rect(l, h), { z: -w / 2, ry: PI }, q);
  face(r, rect(w, h), { x: l / 2, ry: PI / 2 }, q);
  face(r, rect(w, h), { x: -l / 2, ry: -PI / 2 }, q);
}
