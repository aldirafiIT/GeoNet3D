/* ==========================================================================
   main.js — Titik masuk: menjalankan semuanya setelah semua file dimuat
   Dimuat PALING AKHIR.
   ========================================================================== */

renderMateri();                                  // isi tab Materi (js/materi.js)
numify($('panelMateri'));                         // font angka pada Materi
let numBusy = false;                              // font angka otomatis untuk isi kuis
new MutationObserver(() => {
  if (numBusy) return; numBusy = true;
  numify($('quizBody'));
  numBusy = false;
}).observe($('quizBody'), { childList: true, subtree: true });

buildShape('limas');                              // bentuk awal di Visualisasi
showTab('materi');                                // menu pertama yang tampil
function setMusicStatus(playing) {
    const icon = document.getElementById('music-icon');
    const text = document.getElementById('music-text');
    icon.className = playing
        ? "fa-solid fa-volume-high text-emerald-400"
        : "fa-solid fa-volume-xmark text-rose-400";
    text.innerText = playing ? "Musik: Hidup" : "Musik: Mati";
}

document.addEventListener('DOMContentLoaded', () => {
    window.setTimeout(() => {
        if (quizLock) return;
        const audio = document.getElementById('mainBgm');
        audio.play()
            .then(() => setMusicStatus(true))
            .catch(err => {
                setMusicStatus(false);
                console.log("Autoplay musik diblokir browser:", err);
            });
    }, 1000);
});

function toggleBGM() {
    if (quizLock) return;
    const audio = document.getElementById('mainBgm'); // <-- Ubah dari 'bgm' menjadi 'mainBgm'

    if (audio.paused) {
        audio.play().then(() => {
            setMusicStatus(true);
        }).catch(err => console.log("Gagal memutar audio:", err));
    } else {
        audio.pause();
        setMusicStatus(false);
    }
}