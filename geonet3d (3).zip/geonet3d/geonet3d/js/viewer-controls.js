/* ==========================================================================
   viewer-controls.js — Menu VISUALISASI (3/3): slider, tombol lipat, dan animasi
   buildShape(), applyFold(), setPlaying(), dan loop render.
   ========================================================================== */
let current = 'limas', t = 0, playing = false, dir = 1;
const slider = document.getElementById('slider');
const pct = document.getElementById('pct');
const playBtn = document.getElementById('playBtn');

function disposeRoot() {
  if (!root) return;
  root.traverse(o => { if (o.geometry) o.geometry.dispose(); if (o.material) o.material.dispose(); });
  scene.remove(root);
}
function buildShape(key) {
  current = key; disposeRoot(); folds = []; colorIdx = 0;
  root = new THREE.Group(); scene.add(root);
  SHAPES[key].build(root);
  applyFold(t); renderShapeBtns();
}
function applyFold(v) {
  folds.forEach(f => { f.g.rotation.x = -f.max * v; });
  pct.textContent = Math.round(v * 100) + '%';
}
function renderShapeBtns() {
  const box = document.getElementById('shapeBtns'); box.innerHTML = '';
  Object.entries(SHAPES).forEach(([k, s]) => {
    const b = document.createElement('button');
    b.className = 'py-2 px-2 rounded-xl text-sm font-semibold border ' +
      (k === current ? 'bg-sky-500 text-slate-900 border-sky-400' : 'bg-slate-800 border-slate-700 hover:bg-slate-700');
    b.innerHTML = `<i class="fa-solid ${s.icon} mr-1"></i>${s.name}`;
    b.onclick = () => buildShape(k);
    box.appendChild(b);
  });
}
slider.addEventListener('input', () => { t = slider.value / 100; setPlaying(false); applyFold(t); });
function setPlaying(p) {
  playing = p;
  playBtn.innerHTML = p ? '<i class="fa-solid fa-pause mr-2"></i>Jeda' : '<i class="fa-solid fa-play mr-2"></i>Simulasi Lipat';
  playBtn.className = 'mt-3 w-full py-2 rounded-xl font-bold text-slate-900 ' + (p ? 'bg-amber-400 hover:bg-amber-300' : 'bg-emerald-500 hover:bg-emerald-400');
}
playBtn.onclick = () => setPlaying(!playing);

const clock = new THREE.Clock();
(function loop() {
  requestAnimationFrame(loop);
  const dt = Math.min(clock.getDelta(), 0.05);
  if (playing) {
    t += dir * dt * 0.3;
    if (t >= 1) { t = 1; dir = -1; } else if (t <= 0) { t = 0; dir = 1; }
    slider.value = t * 100; applyFold(t);
  }
  controls.update();
  renderer.render(scene, camera);
})();
