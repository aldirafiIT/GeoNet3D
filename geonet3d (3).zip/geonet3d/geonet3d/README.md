# GeoNet 3D: Interaktif Jaring-jaring Bangun Ruang

## Cara menjalankan (VS Code)
1. File -> **Open Folder...** -> pilih folder `geonet3d` ini (bukan Open File).
2. Pasang ekstensi **Live Server** (Ritwick Dey).
3. Klik kanan `index.html` -> **Open with Live Server** (atau tombol *Go Live*).
4. Butuh internet (Three.js, Tailwind, FontAwesome, dan font dimuat dari CDN).

## Struktur folder
```
geonet3d/
├─ index.html              Kerangka halaman (header, 3 menu, panel, HUD kuis)
├─ css/
│  └─ style.css            Animasi game + font angka "equation"
└─ js/
   ├─ utils.js             Fungsi bantu ($, esc, sleep, shuffle) + font angka
   ├─ audio.js             Efek suara (Web Audio API)
   ├─ viewer-scene.js      Visualisasi 1/3: kamera, cahaya, grid, OrbitControls
   ├─ viewer-shapes.js     Visualisasi 2/3: bidang + engsel, bentuk limas/prisma/kubus/balok
   ├─ viewer-controls.js   Visualisasi 3/3: slider, tombol lipat, animasi, buildShape()
   ├─ tabs.js              Pindah menu + penguncian menu saat kuis
   ├─ materi.js            Menu Materi: teks + gambar SVG bangun ruang & jaring-jaring
   ├─ quiz-data.js         DATA KUIS: daftar soal (BANK) + tema daerah (REGION)
   ├─ quiz.js              Logika kuis petualangan (peta, timer, hasil, pengawasan)
   └─ main.js              Titik masuk: menjalankan semuanya
```

## Mau ubah apa -> buka file mana
| Mau ubah...                               | File                      | Cari...                  |
|-------------------------------------------|---------------------------|--------------------------|
| Soal, kunci jawaban, pembahasan, waktu    | `js/quiz-data.js`         | `const BANK`             |
| Nama/ikon/cerita tiap daerah petualangan  | `js/quiz-data.js`         | `const REGION`           |
| Jumlah nyawa/aturan, alur, tampilan hasil | `js/quiz.js`              | `renderStation`, `finish`|
| Anti-curang (pindah tab, salin)           | `js/quiz.js`              | `pengawasan sederhana`   |
| Teks materi & rumus                       | `js/materi.js`            | `const MATERI`           |
| Gambar contoh bangun ruang/jaring         | `js/materi.js`            | `const GAMBAR`, `JARING` |
| Tinggi limas, ukuran balok                | `js/viewer-shapes.js`     | `H_PYR`, `box(`          |
| Kecepatan animasi lipat                   | `js/viewer-controls.js`   | `dt * 0.3`               |
| Warna latar/cahaya 3D                     | `js/viewer-scene.js`      | `0x0a0f1d`, `Light`      |
| Judul, tombol menu, tata letak panel      | `index.html`              | -                        |
| Animasi & font angka                      | `css/style.css`           | -                        |

## Catatan penting
- **Urutan `<script>` di bagian bawah `index.html` jangan diubah**: file saling bergantung.
- Jumlah soal ikut otomatis dari panjang `BANK`. Teks "/10" di HUD (`index.html`) masih manual.
- Soal bergambar jaring-jaring: `o: ['','','','']` + `n: [4 susunan]`, tiap petak `[kolom, baris]`.
